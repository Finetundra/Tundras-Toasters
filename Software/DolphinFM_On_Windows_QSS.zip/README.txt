This is a small Windows batch script and stylesheet for the Dolphin file manager on Windows. 

The paths in the batch file are simply to use as reference for reproducing the script. 

The stylesheet uses a simple hex color code to set the background color for the file manager
